<footer class="container" style="margin:2rem auto 4rem; color:var(--muted);">
  <div style="display:flex; align-items:center; gap:.5rem;">
    <div style="width:10px;height:10px;border-radius:50%;background:#C8EEEA;"></div>
    <div>Distribuidor oficial · Pergamino y la zona</div>
  </div>
</footer>
<div id="cartDrawer" class="cart-drawer">
  <div class="cart-header">
    <strong>Tu carrito</strong>
    <button class="btn outline" onclick="cartDrawer.close()">Cerrar</button>
  </div>
  <div id="cartItems" class="cart-items"></div>
  <div class="cart-footer">
    <button id="checkoutBtn" class="btn" style="width:100%;">Confirmar pedido</button>
  </div>
</div>
</body>
</html>
