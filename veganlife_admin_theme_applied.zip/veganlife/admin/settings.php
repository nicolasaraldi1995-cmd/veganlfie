<?php $active='settings'; $page_title='Configuración'; require __DIR__."/_layout_top.php"; ?>
  <div class="form-container">
    <div class="table-title">Configuración</div>
    <p class="muted">Pantalla en preparación.</p>
  </div>
<?php require __DIR__."/_layout_bottom.php"; ?>
